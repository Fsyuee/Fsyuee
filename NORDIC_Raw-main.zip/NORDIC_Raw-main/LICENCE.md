© 2021 Regents of the University of Minnesota

NORDIC and NIFTI_NORDIC is copyrighted by Regents of the University of Minnesota and covered by US 10,768,260. 
Regents of the University of Minnesota will license the use of NORDIC and NIFTI_NORDIC solely for educational 
and research purposes by non-profit institutions and US government agencies only. For other proposed uses, 
contact umotc@umn.edu. The software may not be sold or redistributed without prior approval. One may make 
copies of the software for their use provided that the copies, are not sold or distributed, are used under 
the same terms and conditions. As unestablished research software, this code is provided on an "as is'' basis
without warranty of any kind, either expressed or implied. The downloading, or executing any part of this
software constitutes an implicit agreement to these terms. These terms and conditions are subject to change 
at any time without prior notice.
